const $=s=>document.querySelector(s);
let current=null,character=null,adminMode=false;
async function api(url,opts={}){const r=await fetch(url,{credentials:"same-origin",headers:{"Content-Type":"application/json"},...opts});const d=await r.json();if(!r.ok)throw Error(d.error||"Erro");return d}
function msg(id,t){$(id).textContent=t}
document.querySelectorAll("[data-tab]").forEach(b=>b.onclick=()=>{document.querySelectorAll("[data-tab]").forEach(x=>x.classList.toggle("active",x===b));$("#loginForm").classList.toggle("hidden",b.dataset.tab!=="login");$("#registerForm").classList.toggle("hidden",b.dataset.tab!=="register");msg("#authMsg","")});
$("#loginForm").onsubmit=async e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.target));try{await api("/api/login",{method:"POST",body:JSON.stringify(d)});await enterGame()}catch(x){msg("#authMsg",x.message)}};
$("#registerForm").onsubmit=async e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.target));try{await api("/api/register",{method:"POST",body:JSON.stringify(d)});await api("/api/login",{method:"POST",body:JSON.stringify({username:d.username,password:d.password})});await enterGame()}catch(x){msg("#authMsg",x.message)}};
$("#logout").onclick=async()=>{await api("/api/logout",{method:"POST"});location.reload()};
async function enterGame(){const me=await api("/api/me");current=me.account;const data=await api("/api/character");character=data.character;if(!character){msg("#authMsg","Conta sem personagem. Fale com o administrador.");return}$("#auth").classList.add("hidden");$("#game").classList.remove("hidden");$("#logout").classList.remove("hidden");$("#charName").textContent=character.name;$("#charInfo").textContent=`${character.class} • Nível ${character.level}`;$("#gold").textContent=character.gold;if(current.role==="admin")$("#adminBtn").classList.remove("hidden");draw(); }
const canvas=$("#world"),ctx=canvas.getContext("2d");
function draw(){if(!character)return;ctx.clearRect(0,0,840,600);
// chão quadriculado
for(let y=0;y<600;y+=48)for(let x=0;x<840;x+=48){ctx.fillStyle=((x+y)/48)%2?"#385b45":"#41664a";ctx.fillRect(x,y,48,48)}
// caminhos
ctx.fillStyle="#9b885f";ctx.fillRect(0,260,840,78);ctx.fillRect(365,0,85,600);
ctx.fillStyle="#766344";ctx.fillRect(365,0,85,600);ctx.fillStyle="#a8956a";ctx.fillRect(0,260,840,78);
// lago e árvores
ctx.fillStyle="#356f83";ctx.beginPath();ctx.ellipse(130,115,85,52,0,0,Math.PI*2);ctx.fill();
for(const [x,y] of [[70,390],[120,440],[700,100],[760,155],[620,440],[220,70],[540,70]]){ctx.fillStyle="#583f2b";ctx.fillRect(x-5,y,10,20);ctx.fillStyle="#204b35";ctx.beginPath();ctx.arc(x,y,22,0,Math.PI*2);ctx.fill();ctx.fillStyle="#36704a";ctx.beginPath();ctx.arc(x-5,y-7,14,0,Math.PI*2);ctx.fill()}
ctx.fillStyle="#e7ce8d";ctx.font="bold 18px Georgia";ctx.fillText("VILA DA AURORA",490,42);
ctx.fillStyle="#d9c38b";ctx.fillRect(540,65,125,75);ctx.fillStyle="#57402d";ctx.fillRect(555,85,95,55);ctx.fillStyle="#d7bd7d";ctx.font="14px Georgia";ctx.fillText("Portal",380,245);
ctx.fillStyle="#f2d06e";ctx.beginPath();ctx.arc(407,285,15,0,Math.PI*2);ctx.fill();ctx.fillStyle="#233044";ctx.fillRect(401,300,12,20);ctx.fillStyle="#fff";ctx.font="12px Arial";ctx.fillText(character.name,370,265);
}
let moveTimer=null;
async function moveTo(x,y){if(!character)return;character.x=Math.max(30,Math.min(810,x));character.y=Math.max(30,Math.min(570,y));draw();clearTimeout(moveTimer);moveTimer=setTimeout(async()=>{try{await api("/api/character/move",{method:"POST",body:JSON.stringify({x:character.x,y:character.y})})}catch{}},250)}
canvas.addEventListener("click",e=>{const r=canvas.getBoundingClientRect();moveTo((e.clientX-r.left)*840/r.width,(e.clientY-r.top)*600/r.height)});
window.addEventListener("keydown",e=>{if($("#game").classList.contains("hidden"))return;const k=e.key.toLowerCase();const step=18;if(["arrowup","arrowdown","arrowleft","arrowright","w","a","s","d"].includes(k)){e.preventDefault();moveTo(character.x+((k==="arrowright"||k==="d")?step:(k==="arrowleft"||k==="a")?-step:0),character.y+((k==="arrowdown"||k==="s")?step:(k==="arrowup"||k==="w")?-step:0))}});
$("#adminBtn").onclick=showAdmin;$("#backGame").onclick=()=>{$("#admin").classList.add("hidden");$("#game").classList.remove("hidden")};
async function showAdmin(){try{const d=await api("/api/admin/overview");$("#players").textContent=d.players;$("#characters").textContent=d.characters;$("#playerRows").innerHTML="";for(const p of d.list){const tr=document.createElement("tr");[p.username,p.name||"—",p.class||"—",p.level??"—",p.gold??"—"].forEach(v=>{const td=document.createElement("td");td.textContent=v;tr.append(td)});const td=document.createElement("td");if(p.name){const gold=document.createElement("button");gold.textContent="+100 ouro";gold.onclick=()=>adminAction(p.name,"grant-gold",{amount:100});const level=document.createElement("button");level.textContent="Nível 10";level.onclick=()=>adminAction(p.name,"set-level",{level:10});td.append(gold,level)}tr.append(td);$("#playerRows").append(tr)}$("#game").classList.add("hidden");$("#admin").classList.remove("hidden")}catch(e){msg("#adminMsg",e.message)}}
async function adminAction(name,action,body){try{await api(`/api/admin/character/${encodeURIComponent(name)}/${action}`,{method:"POST",body:JSON.stringify(body)});msg("#adminMsg",`Alteração aplicada em ${name}.`);await showAdmin()}catch(e){msg("#adminMsg",e.message)}}
(async()=>{try{const m=await api("/api/me");if(m.account)await enterGame()}catch{}})();
