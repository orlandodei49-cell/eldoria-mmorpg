const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const db = new Database(process.env.DB_FILE || "eldoria.db");
const PORT = Number(process.env.PORT || 3000);
const ADMIN_USER = process.env.ADMIN_USER || "admin";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;

if (!ADMIN_PASSWORD || ADMIN_PASSWORD.length < 12) {
  console.error("Defina ADMIN_PASSWORD com pelo menos 12 caracteres antes de iniciar.");
  process.exit(1);
}

db.exec(`
CREATE TABLE IF NOT EXISTS accounts (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'player',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS characters (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 account_id INTEGER NOT NULL REFERENCES accounts(id),
 name TEXT UNIQUE NOT NULL,
 class TEXT NOT NULL CHECK(class IN ('Cavaleiro','Arqueira','Maga')),
 level INTEGER NOT NULL DEFAULT 1,
 gold INTEGER NOT NULL DEFAULT 100,
 x INTEGER NOT NULL DEFAULT 420,
 y INTEGER NOT NULL DEFAULT 300
);
`);
const count = db.prepare("SELECT COUNT(*) n FROM accounts WHERE role='admin'").get().n;
if (!count) {
  const hash = bcrypt.hashSync(ADMIN_PASSWORD, 12);
  db.prepare("INSERT INTO accounts(username,password_hash,role) VALUES(?,?,?)")
    .run(ADMIN_USER, hash, "admin");
}

app.use(express.json({limit:"32kb"}));
app.use(session({
  secret: process.env.SESSION_SECRET || "change-this-session-secret-before-deploy",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly:true, sameSite:"lax", secure: process.env.NODE_ENV === "production", maxAge: 8*60*60*1000 }
}));
app.use(express.static(path.join(__dirname,"public")));

const requireAuth = (req,res,next) => req.session.account ? next() : res.status(401).json({error:"Faça login."});
const requireAdmin = (req,res,next) => {
  if (!req.session.account || req.session.account.role !== "admin") return res.status(403).json({error:"Acesso exclusivo do administrador."});
  next();
};

app.post("/api/login", (req,res) => {
  const {username,password} = req.body || {};
  if (!username || !password) return res.status(400).json({error:"Informe usuário e senha."});
  const account = db.prepare("SELECT * FROM accounts WHERE username=?").get(username);
  if (!account || !bcrypt.compareSync(password,account.password_hash)) return res.status(401).json({error:"Usuário ou senha inválidos."});
  req.session.account = {id:account.id,username:account.username,role:account.role};
  res.json({account:req.session.account});
});
app.post("/api/logout", (req,res) => req.session.destroy(()=>res.json({ok:true})));
app.get("/api/me", (req,res) => res.json({account:req.session.account || null}));

app.post("/api/register", (req,res) => {
  const {username,password,characterName,characterClass} = req.body || {};
  if (!username || username.length < 3 || !password || password.length < 10 ||
      !characterName || characterName.length < 3 ||
      !["Cavaleiro","Arqueira","Maga"].includes(characterClass))
    return res.status(400).json({error:"Confira os dados: usuário (3+), senha (10+), nome (3+) e classe."});
  try {
    const hash = bcrypt.hashSync(password,12);
    const result = db.prepare("INSERT INTO accounts(username,password_hash) VALUES(?,?)").run(username,hash);
    db.prepare("INSERT INTO characters(account_id,name,class) VALUES(?,?,?)").run(result.lastInsertRowid,characterName,characterClass);
    res.json({ok:true});
  } catch { res.status(409).json({error:"Usuário ou nome de personagem já existe."}); }
});
app.get("/api/character", requireAuth, (req,res) => {
  const c = db.prepare("SELECT id,name,class,level,gold,x,y FROM characters WHERE account_id=?").get(req.session.account.id);
  res.json({character:c || null});
});
app.post("/api/character/move", requireAuth, (req,res) => {
  const {x,y} = req.body || {};
  if (!Number.isFinite(x) || !Number.isFinite(y)) return res.status(400).json({error:"Posição inválida."});
  const nx=Math.max(30,Math.min(810,Math.round(x))), ny=Math.max(30,Math.min(570,Math.round(y)));
  db.prepare("UPDATE characters SET x=?,y=? WHERE account_id=?").run(nx,ny,req.session.account.id);
  res.json({x:nx,y:ny});
});
app.get("/api/admin/overview", requireAdmin, (req,res) => {
  const players=db.prepare("SELECT COUNT(*) n FROM accounts WHERE role='player'").get().n;
  const characters=db.prepare("SELECT COUNT(*) n FROM characters").get().n;
  const list=db.prepare("SELECT a.username,c.name,c.class,c.level,c.gold FROM accounts a LEFT JOIN characters c ON c.account_id=a.id WHERE a.role='player' ORDER BY a.created_at DESC LIMIT 100").all();
  res.json({players,characters,list});
});
app.post("/api/admin/character/:name/grant-gold", requireAdmin, (req,res) => {
  const amount=Number(req.body.amount);
  if (!Number.isInteger(amount) || amount<1 || amount>1000000) return res.status(400).json({error:"Quantidade inválida (1 a 1.000.000)."});
  const result=db.prepare("UPDATE characters SET gold=gold+? WHERE name=?").run(amount,req.params.name);
  if (!result.changes) return res.status(404).json({error:"Personagem não encontrado."});
  res.json({ok:true});
});
app.post("/api/admin/character/:name/set-level", requireAdmin, (req,res) => {
  const level=Number(req.body.level);
  if (!Number.isInteger(level) || level<1 || level>200) return res.status(400).json({error:"Nível deve ser de 1 a 200."});
  const result=db.prepare("UPDATE characters SET level=? WHERE name=?").run(level,req.params.name);
  if (!result.changes) return res.status(404).json({error:"Personagem não encontrado."});
  res.json({ok:true});
});
app.get("/health",(req,res)=>res.json({status:"online",game:"Eldoria",version:"0.1.0"}));
app.listen(PORT,()=>console.log(`Eldoria iniciado em http://localhost:${PORT}`));
