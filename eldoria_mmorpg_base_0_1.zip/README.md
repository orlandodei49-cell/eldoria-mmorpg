# Eldoria MMORPG — base 0.1.0

Protótipo inicial original: cliente web 2D, cadastro/login, três classes iniciais, salvamento de posição e painel ADM básico.

## Requisitos
- Node.js 20+
- npm

## Executar localmente
1. Extraia o ZIP.
2. No terminal, entre na pasta do projeto.
3. Defina credenciais fortes para o administrador e uma chave de sessão:
   - Linux/macOS:
     `export ADMIN_USER=admin`
     `export ADMIN_PASSWORD='uma-senha-com-12-ou-mais-caracteres'`
     `export SESSION_SECRET='uma-chave-aleatoria-longa'`
   - Windows PowerShell:
     `$env:ADMIN_USER='admin'`
     `$env:ADMIN_PASSWORD='uma-senha-com-12-ou-mais-caracteres'`
     `$env:SESSION_SECRET='uma-chave-aleatoria-longa'`
4. Rode `npm install`.
5. Rode `npm start`.
6. Abra `http://localhost:3000`.

## Importante
- O banco SQLite `eldoria.db` é criado automaticamente.
- A conta ADM é criada na primeira inicialização, com as variáveis de ambiente acima.
- Não publique diretamente na internet sem HTTPS, proteção contra tentativas de login, armazenamento de sessão persistente, backups, política de privacidade e revisão de segurança.
- Este é o primeiro alicerce funcional, não um MMORPG completo ainda. Combate, inventário, quests, forja, guildas, PvP, chat, mapas adicionais e infraestrutura de produção são etapas seguintes.
- Todo conteúdo visual e código são originais; não inclui arquivos ou ativos do Legend Online.
